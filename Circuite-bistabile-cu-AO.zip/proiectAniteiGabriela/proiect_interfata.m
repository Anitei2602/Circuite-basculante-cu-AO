clear all;
close all;

R = 1e3;
C = 1e-6;
E = 5;
R1 = 10e3;
R2 = 20e3;
R3 = 1.5e3;
C1 = 10e-9;

proiect(R, C, E, R1, R2, R3, C1);