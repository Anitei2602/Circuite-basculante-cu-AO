function proiect(R, C, E, R1, R2, R3, C1)

    Fig = figure('Name', 'Cirucite basculante', ...
        'Units', 'normalized', ...
        'Position', [0.2 0.2 0.6 0.4], ...
        'NumberTitle', 'off', ...
        'color', '#F2D0FF');

 % Crearea meniului Documentatie
f = uimenu('Label', 'Documentatie','Callback', 'open(''documentatie.docx'')');

    PopUpMenu = uicontrol('Style', 'PopupMenu',...
                          'Units', 'normalized',...
                          'Position', [0.8 0.85 0.10 0.05],...
                          'String', 'Astabil|Monostabil',...
                          'Callback', @popupCallback);

    uicontrol('Style','text',... % Text Buton pentru E
             'Units','normalized',...
             'Position',[0.8 0.73 0.05 .03],...
             'backgroundcolor','#EF88BE',...
             'string','E');

    uicontrol('Style','edit',... % edit pt E
             'Units','normalized',...
             'Position',[0.8 0.70 0.05 .03],...
             'String',E,...
             'Callback',['E=','str2num(get(gco,''String''))']);

    uicontrol('Style','text',... % Text Buton pentru R
             'Units','normalized',...
             'Position',[0.9 0.73 0.05 .03],...
             'backgroundcolor','#EF88BE',...
             'string','R');

    uicontrol('Style','edit',... % edit pt R
             'Units','normalized',...
             'Position',[0.9 0.70 0.05 .03],...
             'String',R,...
             'Callback',['R=','str2num(get(gco,''String''))']);

    uicontrol('Style','text',... % Text Buton pentru R2
             'Units','normalized',...
             'Position',[0.9 0.63 0.05 .03],...
             'backgroundcolor','#EF88BE',...
             'string','R2');

    uicontrol('Style','edit',... % edit pt R2
             'Units','normalized',...
             'Position',[0.9 0.60 0.05 .03],...
             'String',R2,...
             'Callback',['R2=','str2num(get(gco,''String''))']);

    uicontrol('Style','text',... % Text Buton pentru R1
             'Units','normalized',...
             'Position',[0.8 0.63 0.05 .03],...
             'backgroundcolor','#EF88BE',...
             'string','R1');

    uicontrol('Style','edit',... % edit pt R1
             'Units','normalized',...
             'Position',[0.8 0.60 0.05 .03],...
             'String',R1,...
             'Callback',['R1=','str2num(get(gco,''String''))']);

    uicontrol('Style','text',... % Text Buton pentru C
             'Units','normalized',...
             'Position',[0.85 0.53 0.05 .03],...
             'backgroundcolor','#EF88BE',...
             'string','C');

    uicontrol('Style','edit',... % edit pt C
             'Units','normalized',...
             'Position',[0.85 0.50 0.05 .03],...
             'String',C,...
             'Callback',['C=','str2num(get(gco,''String''))']);

    uicontrol('Style','pushbutton',... % buton de set
             'Units','normalized',...
             'Position',[0.9 0.2 0.08 .05],...
             'string','SET',...
             'Callback','close;proiectAniteiGabriela(R, C, E, R1, R2, R3, C1)');

    switch get(PopUpMenu, 'Value')
        case 1
             x = imread('C:\Users\anite\OneDrive\Desktop\GAC\proiectAniteiGabriela\astabilAO.jpg');
            subplot(221);
            image(x); 
            title('Circuit basculant astabil cu AO');

            T1 = 2 * R * C * log(1 + (2 * R1) / R2);
            f = 1 / T1;

            t = 0:T1/99:3*T1;
            vo = E * square(2 * pi * f * t);
            subplot(223);
            plot(t, vo);
            hold on; % Păstrează graficul curent pe figură

            % Adăugare secțiune pentru tensiunea pe condensator
            vp = (R1 / (R1 + R2)) * E;
            Vc = zeros(size(t));
            for i = 2:length(t)
                Vc(i) = Vc(i-1) + (vo(i-1) - Vc(i-1)) / (R * C) * (t(i) - t(i-1));

                % Verificare pentru trecerea pragului
                if Vc(i) > vp
                    Vc(i) = vp;
                end
            end

            % Adăugare secțiune pentru tensiunea pe condensator în același grafic
            plot(t, Vc);

            title('Semnal Dreptunghi-Triunghi - Astabil');
            xlabel('Timp[ms]');
            ylabel('Amplitudine[V]');
            legend('Vout', 'Vc');
            grid on;
            hold off; % Termină păstrarea graficului curent pe figură


        case 2
            y = imread('C:\Users\anite\OneDrive\Desktop\GAC\proiectAniteiGabriela\monostabilAO.jpg');
            subplot(221);
            image(y); 
            title('Circuit basculant monostabil cu AO');

            uicontrol('Style','text',... % Text Buton pentru R3
                      'Units','normalized',...
                      'Position',[0.9 0.43 0.05 .03],...
                      'backgroundcolor','#EF88BE',...
                      'string','R3');

            uicontrol('Style','edit',... % edit pt R3
                      'Units','normalized',...
                      'Position',[0.9 0.40 0.05 .03],...
                      'String',R3,...
                      'Callback',['R3=','str2num(get(gco,''String''))']);

            uicontrol('Style','text',... % Text Buton pentru C1
                      'Units','normalized',...
                      'Position',[0.8 0.43 0.05 .03],...
                      'backgroundcolor','#EF88BE',...
                      'String','C1');

            uicontrol('Style','edit',... % edit pt C1
                      'Units','normalized',...
                      'Position',[0.8 0.40 0.05 .03],...
                      'String',C1,...
                      'Callback',['C1=','str2num(get(gco,''String''))']);
            % Calculul timpilor asociați
             t1 = R1 * C;
             t2 = (R2 + R3) * C;
             T = t1 + t2;
             f=1/T;
             % Timpul de simulare
              t = 0:0.0001:3*T;

             % Simularea semnalului de trigger
             trigger = square(2 * pi * f * t) > 0;

             % Simularea tensiunii de intrare
             Vin = E/2+E/2 * square(2 * pi * f * t);

             subplot(223);
             plot(t, Vin);
             hold on;   
            % Simularea tensiunii de ieșire (Vc)
            Vo = zeros(size(t));
            Vc_prev = 0;

            for i = 2:length(t)
                % Dacă triggerul este activ, actualizează Vc
                if trigger(i) && ~trigger(i-1)
                     Vc_prev = E;
                end

                % Actualizează Vc în funcție de evoluția timpului
                Vo(i) = Vc_prev * exp(-(t(i)-t(i-1))/t2);
                Vc_prev = Vo(i);
            end

            % Afișarea rezultatelor pe același grafic

            plot(t, Vc);
            title('Semnal Dreptunghi-Triunghi - Monostabil');
            xlabel('Timp (ms)');
            ylabel('Amplitudine (V)');
            grid on;
            legend('Vin', 'Vout');
            hold off;
       end

    function popupCallback(~, ~)
        selectedOption = get(PopUpMenu, 'Value');
        switch selectedOption
            case 1
                 x = imread('C:\Users\anite\OneDrive\Desktop\GAC\proiectAniteiGabriela\astabilAO.jpg');
            subplot(221);
            image(x); 
            title('Circuit basculant astabil cu AO');

            T1 = 2 * R * C * log(1 + (2 * R1) / R2);
            f = 1 / T1;

            t = 0:T1/99:3*T1;
            vo = E * square(2 * pi * f * t);

            subplot(223);
            plot(t, vo);
            hold on; % Păstrează graficul curent pe figură

            % Adăugare secțiune pentru tensiunea pe condensator
            vp = (R1 / (R1 + R2)) * E;
            Vc = zeros(size(t));
            for i = 2:length(t)
                Vc(i) = Vc(i-1) + (vo(i-1) - Vc(i-1)) / (R * C) * (t(i) - t(i-1));

                % Verificare pentru trecerea pragului
                if Vc(i) > vp
                    Vc(i) = vp;
                end
            end

            % Adăugare secțiune pentru tensiunea pe condensator în același grafic
            plot(t, Vc);

            title('Semnal Dreptunghi-Triunghi - Astabil');
            xlabel('Timp[ms]');
            ylabel('Amplitudine[V]');
            legend('Vout', 'Vc');
            grid on;
            hold off; % Termină păstrarea graficului curent pe figură


            case 2
                 y = imread('C:\Users\anite\OneDrive\Desktop\GAC\proiectAniteiGabriela\monostabilAO.jpg');
            subplot(221);
            image(y); 
            title('Circuit basculant monostabil cu AO');

            uicontrol('Style','text',... % Text Buton pentru R3
                      'Units','normalized',...
                      'Position',[0.9 0.43 0.05 .03],...
                      'backgroundcolor','#EF88BE',...
                      'string','R3');

            uicontrol('Style','edit',... % edit pt R3
                      'Units','normalized',...
                      'Position',[0.9 0.40 0.05 .03],...
                      'String',R3,...
                      'Callback',['R3=','str2num(get(gco,''String''))']);

            uicontrol('Style','text',... % Text Buton pentru C1
                      'Units','normalized',...
                      'Position',[0.8 0.43 0.05 .03],...
                      'backgroundcolor','#EF88BE',...
                      'String','C1');

            uicontrol('Style','edit',... % edit pt C1
                      'Units','normalized',...
                      'Position',[0.8 0.40 0.05 .03],...
                      'String',C1,...
                      'Callback',['C1=','str2num(get(gco,''String''))']);
            % Calculul timpilor asociați
            t1 = R1 * C;
            t2 = (R2 + R3) * C;
            T = t1 + t2;
            f=1/T;
            % Timpul de simulare
            t = 0:0.0001:3*T;

            % Simularea semnalului de trigger
            trigger = square(2 * pi * f * t) > 0;

            % Simularea tensiunii de intrare
            Vin = E/2+E/2 * square(2 * pi * f * t);

            subplot(223);
            plot(t, Vin);
            hold on;   
            % Simularea tensiunii de ieșire (Vc)
            Vo = zeros(size(t));
            Vc_prev = 0;

            for i = 2:length(t)
                % Dacă triggerul este activ, actualizează Vc
                    if trigger(i) && ~trigger(i-1)
                        Vc_prev = E;
                    end

                % Actualizează Vc în funcție de evoluția timpului
                Vo(i) = Vc_prev * exp(-(t(i)-t(i-1))/t2);
                Vc_prev = Vo(i);
            end

            % Afișarea rezultatelor pe același grafic

            plot(t, Vo);
            title('Semnal Dreptunghi-Triunghi - Monostabil');
            xlabel('Timp (ms)');
            ylabel('Amplitudine (V)');
            grid on;
            legend('Vin', 'Vout');
            hold off;

        end
    end 
end